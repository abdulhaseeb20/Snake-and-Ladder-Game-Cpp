#include"header.h"
int main()
{
    func1();
    return 0;
}